<img src="./assets/images/herobanner.png">

<br>

<div>
 <div>
  <img src="./assets/images/haruhiro.png" align="left">
  <p align="right">

   &nbsp;
    
   &nbsp;&#10022; Just call me **Old Cat**

   &nbsp;&#10022; Currently pursuing an applied bachelor's degree in **informatics engineering**

   &nbsp;&#10022; Have good understanding of Web Development

   &nbsp;&#10022; Have understanding in Bahasa (native), English (fluent), 日本語 (a little bit)

   &nbsp;&#10022; My current goals is To become Fullstack Web Developer, and Get N5 日本語 certificate
   
   &nbsp;&#10022; Let's talk about Web development, Security, And Anime stuff
   
  </p>
 </div>
</div>

<br><br><br><br><br><br>
<h2 align="center">🧑‍💻 Most Used Technologies 🧑‍💻</h2>
<br>
<p align="center">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/csharp/csharp-original.svg" alt="csharp" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/dotnetcore/dotnetcore-original.svg" alt="dotnetcore" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg" alt="postgresql" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" alt="mongodb" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/docker/docker-plain.svg" alt="docker" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/kubernetes/kubernetes-plain.svg" alt="docker" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" alt="javascript" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg" alt="typescript" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" alt="nodejs" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" alt="react" width="54" height="54" style="vertical-align:top; margin:4px;">
    <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redux/redux-original.svg" alt="redux" width="54" height="54" style="vertical-align:top; margin:4px;">
</p>
<h2></h2>
<br><br><br><br><br>

<div>
 <div>
  <img src="./assets/images/mary.png" align="left">
  <p align="right">

   &nbsp;
   
   &nbsp;
    
   &nbsp;&#10022; Feel free to reach me at: &#10022;

   &nbsp; 
   <a href="https://discord.com/users/1122382759990657044" target="_blank"><img src="https://img.shields.io/badge/discord-%237289DA.svg?&style=for-the-badge&logo=discord&logoColor=white" /></a>
   <a href="https://www.instagram.com/oldcat.ash" target="_blank"><img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white" /></a>

   &nbsp;&#10022; I ussualy use Discord for chatting with friends.
   
   &nbsp;&#10022; I use Instagram for uploading my drawing content.
   
  </p>
 </div>
</div>
